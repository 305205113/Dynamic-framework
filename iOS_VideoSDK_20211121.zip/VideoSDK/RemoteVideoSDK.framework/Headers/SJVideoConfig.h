//
//  SJVideoConfig.h
//  WYLemonVideo
//
//  Created by AlongShi on 2020/4/14.
//  Copyright © 2020 shujin. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SJVideoConfig : NSObject
/**
 api服务地址 例如：http://www.shujinclound.com
*/
@property (nonatomic, copy) NSString *serverUrl;

/// 国际化资源文件路径 设置则修改加载路径
/// 例如 /var/containers/Bundle/Application/794C54F2-7E8D-46EA-9F94-77711DCD9129/VideoSDKSwiftExample.app/Frameworks/xxx.framework/SJLanguage.bundle
@property (nonatomic, copy) NSString * languagePath;

/// 图片资源文件路径 设置则修改加载路径
/// 例如 /var/containers/Bundle/Application/794C54F2-7E8D-46EA-9F94-77711DCD9129/VideoSDKSwiftExample.app/Frameworks/xxx.framework/SJResource.bundle
@property (nonatomic, copy) NSString * resourcePath;


/// 分享API地址
@property (nonatomic, copy) NSString * shareUrl;

///音视频房间 appId
@property (nonatomic, copy) NSString *appId;
///音视频房间 bizName
@property (nonatomic, copy) NSString *bizName;
///音视频房间 workspaceId
@property (nonatomic, copy) NSString *workspaceId;
///音视频房间 信令地址
@property (nonatomic, copy) NSString *roomServerCustomUrl;

/// 启动IM加密 默认YEES启动
@property (nonatomic, assign) BOOL startTLS;

/// 通讯服务地址
@property (nonatomic, copy) NSString *hostName;

/// 通讯服务端口
@property (nonatomic, assign) UInt16 port;

//#endif


/// web服务地址 例如：http://121.196.19.70:7608
@property (nonatomic, copy) NSString *webUrl;
/**
appkey
*/
@property (nonatomic, copy) NSString *appkey;

/// 是否关闭获取服务器国际化配置 默认 NO不关闭 （设置YES则使用本地国际化SJLanguage.bundle）
@property (nonatomic, assign) BOOL isRemoteLanguageClose;
@end

NS_ASSUME_NONNULL_END
