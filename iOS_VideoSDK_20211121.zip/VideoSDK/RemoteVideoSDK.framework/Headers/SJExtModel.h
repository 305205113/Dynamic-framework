//
//  SJExtModel.h
//  LeimonVideoSDK
//
//  Created by erdong on 2021/6/1.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SJExtModel : NSObject
@property (nonatomic, copy) NSString * ext1;
@property (nonatomic, copy) NSString * ext2;
@property (nonatomic, copy) NSString * ext3;
@property (nonatomic, copy) NSString * ext4;
@property (nonatomic, copy) NSString * ext5;
@end

NS_ASSUME_NONNULL_END
