//
//  SJSessionModel.h
//  LeimonVideoSDk
//
//  Created by AlongShi on 2020/10/12.
//  Copyright © 2020 shujin. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SJSessionModel : NSObject

/// 柜员id
@property (nonatomic, copy) NSString *tellerId;

/// 会话id (全局流水号)
@property (nonatomic, copy) NSString *sessionId;

/// 用户id
@property (nonatomic, copy) NSString *userId;
@end

NS_ASSUME_NONNULL_END
