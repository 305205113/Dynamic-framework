//
//  SJJoinVideoModel.h
//  RemoteVideoSDK
//
//  Created by erdong on 2021/9/16.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SJJoinVideoModel : NSObject
/// 客户号 必传 客户在银行内的唯一标识(注：游客也需要一个唯一标识)
@property (nonatomic, copy) NSString *account;
///音视频房间号 必传
@property (nonatomic, copy) NSString *roomId ;
///音视频房间 token 必传
@property (nonatomic, copy) NSString *mtoken;
///IM 房间号 必传
@property (nonatomic, copy) NSString *imRoomId;
///会话编号 必传
@property (nonatomic, copy) NSString *sessionId;
///用于显示客户姓名 选传
@property (nonatomic, copy) NSString *name;
///用于显示客户地址信息 选传
@property (nonatomic, copy) NSString *address;

@property (nonatomic, copy) NSString *roomServerCustomUrl;
@end

NS_ASSUME_NONNULL_END
