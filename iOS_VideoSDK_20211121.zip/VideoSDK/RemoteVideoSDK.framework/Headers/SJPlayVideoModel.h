//
//  SJPlayVideoModel.h
//  WYLemonVideo
//
//  Created by AlongShi on 2020/4/15.
//  Copyright © 2020 shujin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <RemoteVideoSDK/SJmPaaSConfig.h>
#import <RemoteVideoSDK/SJCallPageConfig.h>
#import <RemoteVideoSDK/SJVideoPageConfig.h>
#import <RemoteVideoSDK/SJAppointmentModel.h>
#import <RemoteVideoSDK/SJExtModel.h>

NS_ASSUME_NONNULL_BEGIN

@interface SJPlayVideoModel : NSObject

/// 客户号 必传 客户在银行内的唯一标识(注：游客也需要一个唯一标识) 
@property (nonatomic, copy) NSString *userId;

/// 机构号 必填
@property (nonatomic, copy) NSString *orgId;

/// 客户账号
@property (nonatomic, copy) NSString *userAccount;

/// 全局流水号
@property (nonatomic, copy) NSString *globalAppointmentNo;

/// 座席号 （点对点呼叫）
@property (nonatomic, copy) NSString * tellerCode;

///// 预约编号
//@property (nonatomic, copy) NSString * orderNo;

/// 渠道编号
@property (nonatomic, copy) NSString * channelNo;

/// 业务编号
@property (nonatomic, copy) NSString * businessNo;

/// mPaas配置 ip
@property (nonatomic, copy) NSString * mpsId;

/// 地理位置 eg:中国xx省xx市xx区xx路xxx号
@property (nonatomic, copy) NSString *location;//地址信息
@property (nonatomic, assign) double longitude;//经度
@property (nonatomic, assign) double latitude;//纬度

/// ip
@property (nonatomic, copy) NSString *ip;


/// mpaas配置参数
@property (nonatomic, strong) SJmPaaSConfig *mPaaSConfig;

/// 呼叫页面配置
@property (nonatomic, strong) SJCallPageConfig *callPageConfig;

/// 通话页面配置
@property (nonatomic, strong) SJVideoPageConfig *videoPageConfig;

/// 预约呼叫参数
@property (nonatomic, strong) SJAppointmentModel *appointmentModel;

/// 预留参数
@property (nonatomic, strong) SJExtModel *extModel;


@property (nonatomic, strong) NSDictionary *ext;

/// https 自选证书路径
@property (nonatomic, copy) NSString *certPath;
@end

NS_ASSUME_NONNULL_END
