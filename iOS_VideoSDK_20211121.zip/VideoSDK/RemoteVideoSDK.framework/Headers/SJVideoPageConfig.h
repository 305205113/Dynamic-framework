//
//  SJVideoPageConfig.h
//  LeimonVideoSDK
///
//  Created by erdong on 2021/3/19.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, SJBottomButtonType) {
    ///挂断
    SJBottomButtonTypeHangup = 0,
    ///输入文字
    SJBottomButtonTypeInputtext,
    ///切换语音/视频
    SJBottomButtonTypeAudioOrVideo,
    ///投屏
    SJBottomButtonTypeProjection,
    ///切换摄像头
    SJBottomButtonTypeCamera,
    ///静音
    SJBottomButtonTypeMute,
    ///更多
    SJBottomButtonTypeMore,
};
@class SJBottomButtonModel;
@interface SJVideoPageConfig : NSObject
/// 设置视频通话页面 评论标签
@property (nonatomic, strong) NSArray <NSString *> *videoCommentTagArray;
/// 设置视频通话页面 快捷回复语言
@property (nonatomic, strong) NSArray <NSString *> *videoChatInputArray;

/*
 底部按钮文字和图片修改
 */
/// 挂断
@property (nonatomic, strong) SJBottomButtonModel *hangupModel;
/// 输入文字
@property (nonatomic, strong) SJBottomButtonModel *inputtextModel;
/// 切换音频/视频
@property (nonatomic, strong) SJBottomButtonModel *audioOrVideoModel;
/// 开/关投屏
@property (nonatomic, strong) SJBottomButtonModel *projectionModel;
/// 切换摄像头
@property (nonatomic, strong) SJBottomButtonModel *cameraModel;
/// 静音
@property (nonatomic, strong) SJBottomButtonModel *muteModel;
/// 更多
@property (nonatomic, strong) SJBottomButtonModel *moreModel;

/// 柜员IM消息log
@property (nonatomic, strong) UIImage * tellerIMImage;

/// 柜员IM接通问候消息 为nil或@""则不显示
@property (nonatomic, copy) NSString * tellerConnectIMText;
/*
 暂停
 */
/// 暂停展示的文字
@property (nonatomic, copy) NSString * pauseShowText;
/// 暂停展示的图片
@property (nonatomic, strong) UIImage * pauseShowImage;

/*
 音频
 */
/// 音频通话展示的文字
@property (nonatomic, copy) NSString * audioShowText;
/// 音频通话展示的图片
@property (nonatomic, strong) UIImage * audioShowImage;
/// 音频通话展示的小图片
@property (nonatomic, strong) UIImage * audioShowSmallImage;

/// 展示切换分辨率功能   默认NO 不展示
@property (nonatomic, assign) BOOL showSwitchVideoQuality;
/// 展示座席工号显示功能    默认NO不展示
@property (nonatomic, assign) BOOL showEmployeeNo;
/// 展示时间水印功能   默认NO不展示
@property (nonatomic, assign) BOOL showDateTimeWatermark;
/// 展示地址水印功能   默认NO不展示
@property (nonatomic, assign) BOOL showAddressWatermark;
/// 挂断显示评价弹窗功能   默认NO隐藏
@property (nonatomic, assign) BOOL showEvaluation;
/// 展示悬浮窗按钮   默认NO展示
@property (nonatomic, assign) BOOL showSuspended;

/// 展示聊天按钮   默认NO不展示
@property (nonatomic, assign) BOOL showChatButton;

/// 展示清屏按钮   默认NO隐藏
@property (nonatomic, assign) BOOL showClearScreenButton;

///// 展示视频通话底部按钮背景颜色透明   默认NO
//@property (nonatomic, assign) BOOL showTabberBGColorTranslucent;

- (void)changeBottomButton:(SJBottomButtonType)type textNormal:( NSString * __nullable)textNormal textSelected:(NSString * __nullable)textSelected imageNormal:(UIImage * __nullable)imageNormal imageSelected:(UIImage * __nullable)imageSelected;
@end

@interface SJBottomButtonModel : NSObject

/// 按钮正常文字
@property (nonatomic, copy) NSString * textNormal;
/// 按钮选中文字
@property (nonatomic, copy) NSString * textSelected;
/// 按钮正常状态图片
@property (nonatomic, strong) UIImage *imageNormal;
/// 按钮选中状态图片
@property (nonatomic, strong) UIImage *imageSelected;

@end
NS_ASSUME_NONNULL_END
