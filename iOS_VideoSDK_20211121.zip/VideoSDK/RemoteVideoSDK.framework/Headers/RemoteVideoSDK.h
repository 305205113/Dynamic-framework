//
//  RemoteVideoSDK.h
//  RemoteVideoSDK
//
//  Created by erdong on 2021/8/20.
//

#import <Foundation/Foundation.h>

//! Project version number for RemoteVideoSDK.
FOUNDATION_EXPORT double RemoteVideoSDKVersionNumber;

//! Project version string for RemoteVideoSDK.
FOUNDATION_EXPORT const unsigned char RemoteVideoSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <RemoteVideoSDK/PublicHeader.h>
#import <RemoteVideoSDK/SJVideoSDK.h>
#import <RemoteVideoSDK/SJPlayVideoModel.h>
#import <RemoteVideoSDK/SJmPaaSConfig.h>
#import <RemoteVideoSDK/SJLocationManager.h>
#import <RemoteVideoSDK/SJAppointmentModel.h>
#import <RemoteVideoSDK/SJExtModel.h>
#import <RemoteVideoSDK/SJJoinVideoModel.h>
