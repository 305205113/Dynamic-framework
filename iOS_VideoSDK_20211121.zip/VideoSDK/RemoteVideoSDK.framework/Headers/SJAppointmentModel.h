//
//  SJAppointmentModel.h
//  LeimonVideoSDK
//
//  Created by erdong on 2021/6/1.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SJAppointmentModel : NSObject

/// ///银行参考编号
@property (nonatomic, copy) NSString * bankNo;

/// ///身份证号
@property (nonatomic, copy) NSString * idCard;

/// 预约编号
@property (nonatomic, copy) NSString * orderNo;

/// 备注
@property (nonatomic, copy) NSString * remark;

/// 姓名
@property (nonatomic, copy) NSString * username;

@end

NS_ASSUME_NONNULL_END
