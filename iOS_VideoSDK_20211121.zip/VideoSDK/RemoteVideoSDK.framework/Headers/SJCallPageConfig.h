//
//  SJCallPageConfig.h
//  LeimonVideoSDk
//
//  Created by AlongShi on 2020/10/23.
//  Copyright © 2020 shujin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN

/*
 呼叫界面 使用图片资源在SJResource.bundle中对应名称如下
 背景图片："icon_bank_bg"
 logo："icon_bank_bg"
 头像: "icon_bank_tx"
 轮播图: "icon_pic_banner01"
 挂断按钮: "icon_hangup" 
 */

@interface SJCallPageConfig : NSObject
/// 设置呼叫界面标题
@property (nonatomic, strong) NSString *callTitle;

/// 设置呼叫界面文字颜色
@property (nonatomic, strong) UIColor *callColor;

/// 头像（远程图片）
@property (nonatomic, strong) NSURL *callAvatarUrl;

/// 头像（本地图片）
@property (nonatomic, strong) UIImage *callAvatarImage;

/// 是否显示排队人数（默认显示）
@property (nonatomic, assign) BOOL showQueue;

/// 设置呼叫界面背景 （未设置则默认显示前摄像头画面）
@property (nonatomic, strong) UIImage *callBgImage;

/// 是否显示轮播图（默认隐藏）
@property (nonatomic, assign) BOOL showCallBanner;

/// 设置呼叫界面轮播图（本地图片） 需要设置 showCallBanner 为YES显示
@property (nonatomic, strong) NSArray *callLocalBannerList;

/// 设置呼叫界面轮播图（网络图片）优先级大于本地图片 需要设置 showCallBanner 为YES显示
@property (nonatomic, strong) NSArray *callNetBannerList;

/// 设置呼叫界面 等待中文字
@property (nonatomic, strong) NSString *callAwaitTitle;

/// 设置呼叫界面 等待柜员接听文字
@property (nonatomic, strong) NSString *callTellAwaitTitle;

/// 设置呼叫界面 右上角log图片 size为图片大小 默认无
@property (nonatomic, strong) UIImage *logoImage;
@end

NS_ASSUME_NONNULL_END
